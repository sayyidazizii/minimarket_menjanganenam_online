/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 10.4.19-MariaDB : Database - ciptapro_kasihibu_minimarket
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
USE `ciptapro_kasihibu_minimarket`;

/*Table structure for table `system_menu_mapping` */

DROP TABLE IF EXISTS `system_menu_mapping`;

CREATE TABLE `system_menu_mapping` (
  `menu_mapping_id` int(10) NOT NULL AUTO_INCREMENT,
  `company_id` int(10) DEFAULT NULL,
  `user_group_level` int(3) DEFAULT NULL,
  `id_menu` varchar(10) DEFAULT NULL,
  `data_state` int(1) DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`menu_mapping_id`),
  KEY `FK_system_menu_mapping_id_menu` (`id_menu`),
  CONSTRAINT `FK_system_menu_mapping_id_menu` FOREIGN KEY (`id_menu`) REFERENCES `system_menu` (`id_menu`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4;

/*Data for the table `system_menu_mapping` */

insert  into `system_menu_mapping`(`menu_mapping_id`,`company_id`,`user_group_level`,`id_menu`,`data_state`,`created_at`,`updated_at`) values 
(1,1,1,'0',0,'2022-10-19 14:22:36','2022-10-19 14:22:40'),
(2,1,1,'3',0,'2022-10-19 14:22:53','2022-10-19 14:22:56'),
(3,1,1,'31',0,'2022-10-19 14:23:01','2022-10-19 14:23:04'),
(4,1,1,'321',0,'2022-10-19 14:23:11','2022-10-19 14:23:13'),
(5,1,1,'33',0,'2022-10-19 14:23:17','2022-10-19 14:23:20'),
(6,1,1,'34',0,'2022-10-19 14:23:27','2022-10-19 14:23:29'),
(7,1,1,'341',0,'2022-10-19 14:23:34','2022-10-19 14:23:37'),
(8,1,1,'35',0,'2022-10-19 14:23:41','2022-10-19 14:23:43'),
(9,1,1,'36',0,'2022-10-19 14:23:48','2022-10-19 14:23:52'),
(10,1,1,'37',0,'2022-10-19 14:24:00','2022-10-19 14:24:03'),
(11,1,1,'38',0,'2022-10-19 14:24:07','2022-10-19 14:24:11'),
(12,1,1,'92',0,'2022-10-19 14:25:28','2022-10-19 14:25:31'),
(13,1,1,'32',0,'2022-10-20 14:36:46','2022-10-20 14:36:49'),
(102,1,1,'322',0,'2022-11-07 14:12:44','2022-11-07 14:12:49');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
